package com.br.alura.domain.Topico;


public record AtualizaçãoTopico(String titulo, String mensagem, StatusTopico statusTopico) {
}
