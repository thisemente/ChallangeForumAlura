package com.br.alura.domain.Topico;

public enum StatusTopico {
	NAO_RESPONDIDO,
	NAO_SOLUCIONADO,
	SOLUCIONADO,
	FECHADO;

}
